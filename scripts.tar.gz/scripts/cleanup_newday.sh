#!/usr/local/bin/bash

# This script is executed every start of the date, for example, 6:00 a.m everyday.
# In this script we drop down OpenVPN connections in which attack has been detected by snort but
# cleared to allow to keep in connection
# And then we delete the tables we used last day for monitoring and OVPN client controling.
# Those tables are OpenVPN_Client_List.tbl and and Cleared_Blocked_IP.tbl.

# Get current connected OVPN sessions and check each of them is involved in Cleared_Blocked_IP table
# and if true, drop it.
`php -r "require_once('openvpn.inc'); print_r(openvpn_get_active_servers()[0]['conns']);" > Active_address`

while IFS='' read -r line || [ -n "$line" ]; do
    address_line=`echo $line | grep remote_host | cut -d '>' -f2 | tr -d ' '`

    if [ "$address_line" != "" ]; then
    	# Find out if this address blocked by snort before.
    	remip=`echo $address_line | cut -d ':' -f1`
    	is_blocked="false"

        if [[ ! -f "/etc/Cleared_Blocked_IP.tbl" ]]; then
            break
        fi

    	while IFS='' read -r Blocked_IP || [ -n "$Blocked_IP" ]; do
    		if [ $remip == $Blocked_IP ]; then
    			is_blocked="true"
    			break
    		fi
    	done < "/etc/Cleared_Blocked_IP.tbl"

    	# Drop down OpenVPN connection if it is in blocked ip list table
    	if [ $is_blocked == "true" ]; then
    		mgmt=`php -r "require_once('openvpn.inc'); print_r(openvpn_get_active_servers()[0]['mgmt']);"`
    		php -r "require_once('openvpn.inc'); openvpn_kill_client('$mgmt', '$address_line');"
    		echo removed
    	fi
    fi
done < "Active_address"
rm -rf Active_address

# Clean tables for new day monitoring
rm -rf /etc/Cleared_Blocked_IP.tbl
rm -rf /etc/OpenVPN_Client_List.tbl