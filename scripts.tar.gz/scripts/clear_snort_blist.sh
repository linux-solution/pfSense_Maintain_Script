#!/usr/local/bin/bash

# This script is also executed every 1 minute by the Cron job but after Add_OpenVPN_List.sh has been
# executed since this consider the current connected OpenVPN client IPs.
# In this file we firstly get all blocked IPs by snort and then, in them, we find out to be cleared
# which matches with OpenVPN client IPs so that keep previous connected sessions.

function valid_ip()
{
    local  ip=$1
    local  stat=1

    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        OIFS=$IFS
        IFS='.'
        ip=($ip)
        IFS=$OIFS
        [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 && ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
        stat=$?
    fi
    return $stat
}

# Get Blocked IPs by snort and save in temporary file to compare with OVPN Client List
/sbin/pfctl -t snort2c -T show > blocked_IPs

# Check each OpenVPN Client IP if be in Blocked list
while IFS='' read -r Blocked_IP || [ -n "$Blocked_IP" ]; do
	if [[ ! -f "/etc/OpenVPN_Client_List.tbl" ]]; then
		break
	fi

	is_vpn_client="false"

	while IFS='' read -r OpenVPN_Client_List || [ -n "$OpenVPN_Client_List" ]; do
		if [ $Blocked_IP == $OpenVPN_Client_List ]; then
			is_vpn_client="true"
		fi
	done < "/etc/OpenVPN_Client_List.tbl"

	if [ "$is_vpn_client" == "true" ]; then
		# Save the OpenVPN snort-detected IPs to the table to be monitored by customer
		if valid_ip $Blocked_IP; then 
			echo $Blocked_IP >> /etc/Cleared_Blocked_IP.tbl
		fi
		
		# Clear blocked IP as it matches with OpenVPN client IP
		/sbin/pfctl -t snort2c -T delete $Blocked_IP
	fi
done < "blocked_IPs"

# Remove unnecessary temporary file
rm -rf blocked_IPs