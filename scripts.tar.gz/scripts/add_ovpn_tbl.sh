#!/usr/local/bin/bash

# This script is executed every 1 minites by Cron job.
# In this file, we parse the OpenVPN log file to check if there is any new connected OpenVPN client today.
# If there is new client connected and pool returned, we add this IP in to a OpenVPN client list table of today.

function valid_ip()
{
    local  ip=$1
    local  stat=1

    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        OIFS=$IFS
        IFS='.'
        ip=($ip)
        IFS=$OIFS
        [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 && ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
        stat=$?
    fi
    return $stat
}

# Make OpenVPN log temporary file and Client list file if not exist.
if [ ! -f "/tmp/openvpn.log.tmp" ]; then
	touch /tmp/openvpn.log.tmp
fi
if [ ! -f "/etc/OpenVPN_Client_List.tbl" ]; then
	touch /etc/OpenVPN_Client_List.tbl
fi

# Get new lines in OpenVPN log file in last 1 minutes.
diff /var/log/openvpn.log /tmp/openvpn.log.tmp | grep pool | cut -d '/' -f2 | cut -d ':' -f1 | tr -d ' ' > diff
diff /var/log/openvpn.log /tmp/openvpn.log.tmp | grep cipher | cut -d '/' -f2 | cut -d ':' -f1 | tr -d ' ' >> diff

while IFS=' ' read -r ADDR; do
	for ip in "${ADDR}"; do
		# Check if this IP is alreay exist in tbl.
		exist="false"

		while IFS='' read -r line || [ -n "$line" ]; do
			if [ "$line" == $ip ]; then
				exist="true"
			fi
		done < "/etc/OpenVPN_Client_List.tbl"

		# Add IP in to a tbl if this is new vpn connection today.
		if [ $exist == "false" ]; then
			# Validate IP address
			if valid_ip $ip; then 
				echo $ip >> /etc/OpenVPN_Client_List.tbl
			fi
		fi
	done
done < "diff"
# Remove unnecessary temporary file
rm -rf "diff"

# Copy OpenVPN log file to temporary for the next comparation after 1 minute.
cp /var/log/openvpn.log /tmp/openvpn.log.tmp